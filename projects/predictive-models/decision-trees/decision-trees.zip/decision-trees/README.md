# Decision Trees — ID3 + sklearn

Charlie McChesney · ECON 475 Section 2 · From my [personal portfolio](https://github.com/mcchesneychar).

A from-scratch implementation of the **ID3** decision-tree algorithm at depth 2, alongside a comparison against sklearn's `DecisionTreeClassifier` at depths 2–5 on the same train/test split.

## Run it

```bash
pip install -r requirements.txt
python decision-trees.py
```

Both files live in this folder. The CSV (`section2-dataset.csv`) is a 1,054-row criminal-justice survey: seven binary descriptive features (marital status, urban residence, union membership, HS graduation, brother is a criminal, prior probation, prior charges) → `Committed Crime` target.

## What it teaches

**Information gain.** At each split, every candidate feature is scored by how much it reduces the entropy of the target. The function `entropy(t)` returns the Shannon entropy of a series; `rem(d, t)` returns the weighted entropy that *remains* after splitting on feature `d`; `maxIG(df, t)` walks every column and returns the one with the largest gain.

**ID3 at depth 2.** `dTree(df, t)` picks the root by maximum IG, partitions the data, and on each branch picks the best second-level feature. Leaves return the majority class of whatever observations land there.

**Custom vs. library.** The script prints the depth-2 ID3 tree and its 70/30 accuracy, then runs sklearn at depths 2–5 so you can see the bias/variance trade-off (depth 5 will overfit).

## Use cases

Decision trees shine where interpretability matters as much as accuracy — credit risk, medical triage, regulatory settings — because the output is a sequence of human-readable if/then rules. In production they're almost always wrapped in an ensemble (random forests, gradient-boosted trees) to control the high variance of any single tree.

## Files

| File | Purpose |
|------|---------|
| `decision-trees.py`   | The cleaned implementation. Run it directly. |
| `section2-dataset.csv`| 1,054-row dataset. |
| `requirements.txt`    | Pinned dependencies. |
