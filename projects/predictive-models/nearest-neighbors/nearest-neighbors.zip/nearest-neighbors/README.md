# Nearest Neighbors — 1-NN, k-NN, metric comparisons

Charlie McChesney · ECON 475 Section 3 · From my [personal portfolio](https://github.com/mcchesneychar).

A from-scratch implementation of distance-based prediction (Euclidean, Manhattan, Minkowski-3) plus a benchmark of sklearn's `KNeighborsClassifier` across the `kd_tree` and `brute` algorithms, and a synthetic dataset where cosine similarity meaningfully outperforms Minkowski.

## Run it

```bash
pip install -r requirements.txt
python nearest-neighbors.py
```

## What it teaches

**Distance metrics.** `dist(a, b, method)` swaps between Euclidean (straight-line), Manhattan (sum of absolute differences), and Minkowski-3 (cubic exponent). The choice matters: Euclidean and Manhattan are dominated by feature *magnitude*, while cosine — used in the synthetic experiment — is magnitude-invariant and recovers class structure that lives in feature *direction*.

**1-NN and k-NN.** `predict()` returns the label of the single closest training point under Euclidean distance; `predict2()` returns the plurality label of the *k* closest points under Manhattan. There is no training step — the entire training set is the model.

**Algorithm benchmarks.** `KNN_Speed()` times sklearn's `KNeighborsClassifier` with `algorithm='kd_tree'` vs. `'brute'` on an 80/20 split. On low-dimensional data the kd-tree is a clear win; in higher dimensions brute force catches up.

**When cosine wins.** `dataCreation(seed)` synthesizes a 600-sample, 10-feature, 3-class dataset where each class lives along a base direction in feature space, scaled by random magnitudes from 1 to 1000. Euclidean distance gets dominated by magnitude noise; cosine cleanly separates the classes.

## Use cases

k-NN is the simplest "intelligent" classifier — no training step at all. Common in recommender systems, anomaly detection (flag points whose neighbors are far away), and image / document retrieval. Main weaknesses: every prediction touches every training point unless you use a spatial index, and high-dimensional spaces dilute distance.

## Files

| File | Purpose |
|------|---------|
| `nearest-neighbors.py`  | The cleaned implementation. |
| `section3-dataset.csv`  | 1,054-row dataset (same schema as Section 2 plus 4 continuous features). |
| `requirements.txt`      | Pinned dependencies. |
