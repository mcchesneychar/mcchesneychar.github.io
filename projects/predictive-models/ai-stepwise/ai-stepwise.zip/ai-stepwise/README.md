# AI-Augmented Stepwise Regression

Charlie McChesney · ECON 475 Generative AI Final Project · From my [personal portfolio](https://github.com/mcchesneychar).

A head-to-head comparison of three forward-stepwise linear regressions on the California Housing dataset. The question: **does an LLM's curated feature suggestions actually buy you anything that brute force doesn't?**

## Run it

```bash
pip install -r requirements.txt
python ai-stepwise.py
```

No API key needed — the script ships with a pre-baked Claude response (see comment block in the file). The dataset is downloaded automatically from sklearn (`fetch_california_housing`).

## The three models

| Model | Candidate features | What it does |
|---|---|---|
| **A · Baseline**       | 8  | Forward stepwise on the 8 raw columns. Honest, no-frills. |
| **B · AI-augmented**   | 18 | 8 raw + 10 features Claude suggested when given only the column names and target. |
| **C · Kitchen-sink**   | 44 | 8 raw + every pairwise product (28) + every square (8). Brute force. |

All three use the same forward-stepwise selection (minimize AIC), the same 80/20 split, and are scored on the same holdout RMSE. The only thing that varies is the candidate pool.

## What you'll see

- The **prompt** (verbatim) sent to Claude.
- The **JSON response** Claude returned — 10 engineered features, each with a one-line rationale.
- Each model's **candidates considered**, the features the stepwise actually selected, and the **test RMSE**.
- A summary table and a one-line **interpretation** of the comparison.

## Wiring up a live LLM call

The shipped version uses a hard-coded JSON response so the script runs offline. The top of `ai-stepwise.py` includes a commented-out block sketching how a live call *would* be wired in: `python-dotenv` for the key, `os.environ["LLM_API_KEY"]` to read it, then a call to your provider of choice (Anthropic, Gemini, OpenAI). Add `.env` to your `.gitignore` so the key never gets committed.

## Files

| File | Purpose |
|------|---------|
| `ai-stepwise.py`   | The cleaned implementation. |
| `requirements.txt` | Pinned dependencies. |
