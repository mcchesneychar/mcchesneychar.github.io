# Regression with Gradient Descent

Charlie McChesney · ECON 475 Section 5 · From my [personal portfolio](https://github.com/mcchesneychar).

OLS via statsmodels for reference, a Monte-Carlo sanity check on parameter recovery, then **from-scratch batch gradient descent** for both linear and logistic regression. The "extra credit" path uses feature standardization so descent converges from a random init in <1,000 steps.

## Run it

```bash
pip install -r requirements.txt
python gradient-descent.py
```

## What it teaches

**OLS for reference.** `ols_fit()` uses statsmodels to fit `Wage ~ Education` so you have a closed-form benchmark for what gradient descent should recover.

**Monte-Carlo recovery.** `monte_carlo_recovery()` simulates 1,000 datasets from a known linear model (`y = 2 + 0.5x + noise`) and checks that the OLS estimates of `w[0]` and `w[1]` average to the true parameters — the classic unbiasedness check.

**Linear gradient descent.** `gradient_descent()` minimizes mean-squared error step by step. The gradient of MSE is `(2/n) · Σ(err)` for `w[0]` and `(2/n) · Σ(err·x)` for `w[1]`. Stop condition: the change in loss falls below `tol` or the step cap is hit.

**Logistic gradient descent.** `logistic_gradient_descent()` swaps in the sigmoid + binary cross-entropy. Two gotchas: (1) implement a numerically stable sigmoid so large negative `z` doesn't `exp(big_number)` and overflow, and (2) add a safety brake — if the loss bumps upward, halt instead of diverging.

**Standardization (extra credit).** `gd_standardized()` scales the feature to mean 0 / std 1 before descent. This puts the loss surface on equal scales across parameters and lets descent converge in <1,000 steps from a *random* initialization. The function then un-standardizes the weights back to the original feature space so the printed `w[0]` and `w[1]` are interpretable.

## Use cases

Gradient descent is the scaffolding under nearly every modern predictive model — OLS at scale, logistic regression in production, neural network training (in mini-batch / Adam variants). The pieces that matter in practice are the same as on this page: a sensible learning rate, feature standardization, and a stop condition that catches divergence.

## Files

| File | Purpose |
|------|---------|
| `gradient-descent.py`   | The cleaned implementation. |
| `section5-dataset.csv`  | 1,054-row dataset with continuous and discrete features. |
| `requirements.txt`      | Pinned dependencies. |
