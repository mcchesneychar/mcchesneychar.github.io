# Naive Bayes — full-joint vs Naive Bayes

Charlie McChesney · ECON 475 Section 4 · From my [personal portfolio](https://github.com/mcchesneychar).

A from-scratch implementation of:
- The full-joint conditional probability and Bayesian MAP prediction.
- The Naive Bayes assumption (feature independence) with **Laplace smoothing** for discrete features and a **Gaussian** likelihood for continuous ones.

## Run it

```bash
pip install -r requirements.txt
python naive-bayes.py
```

Heads up: `bayes()` (the full-joint version) is slow — it scans the dataset for every prediction. The script prints a "this may take a few minutes" warning before that test.

## What it teaches

**Bayes' theorem in one direction.** P(class | features) ∝ P(features | class) · P(class). MAP prediction picks whichever class maximizes the right-hand side.

**The full joint is intractable.** `cond_prob()` estimates P(features | class) by counting exact matches in the training set. It works on toy data but the table grows exponentially in the number of features — for any real problem you need to factor it.

**The naive assumption.** `Ncond_prob()` assumes features are conditionally independent given the class, so the joint factors into a product of per-feature likelihoods. Each per-feature term is estimated separately with **Laplace smoothing** (`(count + k) / (n + domain·k)`) to keep unseen values from driving probabilities to zero.

**Continuous features.** When `feature='continuous_desc'`, each per-class likelihood is a Gaussian fit to the within-class mean and standard deviation — the standard "Gaussian Naive Bayes" formulation.

## Use cases

Naive Bayes is the workhorse of text classification (spam filters, sentiment analysis, topic tagging) because it scales linearly with vocabulary size and document count and trains in a single pass. It's also a common first-pass baseline for medical diagnosis. Weaknesses show up when features are strongly correlated or when calibrated probability estimates matter (it's an excellent classifier, a mediocre probability estimator).

## Files

| File | Purpose |
|------|---------|
| `naive-bayes.py`        | The cleaned implementation. |
| `section4-dataset.csv`  | 1,054-row dataset with 7 discrete + 4 continuous features. |
| `requirements.txt`      | Pinned dependencies. |
